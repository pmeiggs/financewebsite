-- ============================================================
-- Personal Finance Tracker - Database Schema
-- DG1IAD Portfolio 3
-- ============================================================

CREATE DATABASE IF NOT EXISTS finance_tracker;
USE finance_tracker;

-- ============================================================
-- Table: users
-- Stores registered user accounts with hashed passwords
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    user_id     INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50)  NOT NULL UNIQUE,
    email       VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Table: categories
-- Predefined and user-defined transaction categories
-- ============================================================
CREATE TABLE IF NOT EXISTS categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(50) NOT NULL UNIQUE
);

-- ============================================================
-- Table: transactions
-- Stores all income and expense transactions per user
-- ============================================================
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT            NOT NULL,
    amount         DECIMAL(19, 2) NOT NULL,
    type           ENUM('income', 'expense') NOT NULL,
    category_id    INT            NOT NULL,
    description    VARCHAR(255),
    date           DATE           NOT NULL,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_transaction_user
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_transaction_category
        FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT
);

-- ============================================================
-- Seed Data: Categories (minimum 3 entries)
-- ============================================================
INSERT INTO categories (name) VALUES
    ('Food'),
    ('Rent'),
    ('Transport'),
    ('Healthcare'),
    ('Entertainment'),
    ('Salary'),
    ('Utilities'),
    ('Shopping'),
    ('Education'),
    ('Other');

-- ============================================================
-- Seed Data: Users (minimum 3 entries)
-- Passwords are bcrypt hashes of 'Password123!'
-- ============================================================
INSERT INTO users (username, email, password_hash) VALUES
    ('alice_smith',  'alice@example.com',  '$2b$10$examplehashforalicessss.....'),
    ('bob_jones',    'bob@example.com',    '$2b$10$examplehashforbobsssssss.....'),
    ('carol_white',  'carol@example.com',  '$2b$10$examplehashforcarolsssss.....');

-- ============================================================
-- Seed Data: Transactions (minimum 3 entries per user)
-- ============================================================
INSERT INTO transactions (user_id, amount, type, category_id, description, date) VALUES
    -- Alice's transactions
    (1, 2500.00, 'income',  6, 'Monthly salary',         '2026-04-01'),
    (1,   45.00, 'expense', 1, 'Grocery shopping',       '2026-04-03'),
    (1,  750.00, 'expense', 2, 'Monthly rent',           '2026-04-05'),
    (1,   30.00, 'expense', 3, 'Bus pass',               '2026-04-06'),
    -- Bob's transactions
    (2, 3200.00, 'income',  6, 'Freelance payment',      '2026-04-01'),
    (2,   65.00, 'expense', 1, 'Restaurant dinner',      '2026-04-04'),
    (2,  900.00, 'expense', 2, 'Apartment rent',         '2026-04-05'),
    -- Carol's transactions
    (3, 1800.00, 'income',  6, 'Part-time job',          '2026-04-02'),
    (3,   25.00, 'expense', 5, 'Cinema tickets',         '2026-04-07'),
    (3,   80.00, 'expense', 4, 'Pharmacy',               '2026-04-08');

-- ============================================================
-- Useful Views
-- ============================================================

-- View: user spending summary
CREATE OR REPLACE VIEW user_spending_summary AS
SELECT
    u.user_id,
    u.username,
    SUM(CASE WHEN t.type = 'income'  THEN t.amount ELSE 0 END) AS total_income,
    SUM(CASE WHEN t.type = 'expense' THEN t.amount ELSE 0 END) AS total_expenses,
    SUM(CASE WHEN t.type = 'income'  THEN t.amount ELSE -t.amount END) AS balance
FROM users u
LEFT JOIN transactions t ON u.user_id = t.user_id
GROUP BY u.user_id, u.username;


-- run this if you already created the database with the old schema.
-- it widens the amount column from decimal(10,2) to decimal(19,2),
-- removing the 99,999,999.99 cap and supporting up to 17 digits.
-- it is safe to run multiple times.
ALTER TABLE transactions MODIFY COLUMN amount DECIMAL(19, 2) NOT NULL;
