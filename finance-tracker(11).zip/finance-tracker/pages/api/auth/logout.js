// pages/api/auth/logout.js
import { securityHeaders } from '../../../lib/securityHeaders';

export default function handler(req, res) {
  securityHeaders(res);
  // clear the session cookie by setting max-age to 0
  res.setHeader('Set-Cookie', 'token=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax');
  res.json({ message: 'Logged out.' });
}
